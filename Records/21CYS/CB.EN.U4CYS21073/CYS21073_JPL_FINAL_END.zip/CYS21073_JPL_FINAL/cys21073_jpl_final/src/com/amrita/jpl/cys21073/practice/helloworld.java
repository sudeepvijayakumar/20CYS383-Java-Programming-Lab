package com.amrita.jpl.cys21073.practice;





/**
 * @author sudeep
 * @version 0.5
 */

public class helloworld {
    /**
     * Main method that prints "Hello world!" to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}